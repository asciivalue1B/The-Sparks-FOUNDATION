DATA SCIENCE AND BUISNESS ANALYTICS INTERN AT SPARKS FOUNDATION

AUTHOR : ANKITA JAISWAL

TASK 1 : Prediction using Supervised ML 

PROBLEM : Predict the percentage of an student based on the no. of study hours


```python
#IMPORTING STANDARD ML LIBRARIES
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
#to read dataset
df=pd.read_csv("https://raw.githubusercontent.com/AdiPersonalWorks/Random/master/student_scores%20-%20student_scores.csv")
```


```python
df.head() #print top 5 row of dataset
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>



PREPARING DATA SET FOR MACHINE LEARNING ALGORITHM


```python
df.isnull().sum() #to check null values
```




    Hours     0
    Scores    0
    dtype: int64




```python
df.describe() #descibing the dataset using statistics
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>25.000000</td>
      <td>25.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.012000</td>
      <td>51.480000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.525094</td>
      <td>25.286887</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.100000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.700000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.800000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.400000</td>
      <td>75.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.200000</td>
      <td>95.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 25 entries, 0 to 24
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   Hours   25 non-null     float64
     1   Scores  25 non-null     int64  
    dtypes: float64(1), int64(1)
    memory usage: 528.0 bytes
    


```python
# Plotting the scores
df.plot(x='Hours', y='Scores', style='o')
plt.title('Hours vs Percentage')  
plt.xlabel('Hours Studied')  
plt.ylabel('Percentage Score')  
plt.show()
```


    
![png](output_11_0.png)
    


SPLITING THE DATASET INTO TRAINING SET AND TEST SET


```python
x = df.iloc[:, :-1].values  
y = df.iloc[:, 1].values
```


```python
from sklearn.model_selection import train_test_split  
x_train, x_test, y_train, y_test = train_test_split(x, y,test_size=0.2, random_state=0)
# we are using 20% dataset for testing
```

TRAINING THE DATA SET USING LINEAR REGRESSION MODEL


```python
from sklearn.linear_model import LinearRegression  
regressor = LinearRegression()  
regressor.fit(x_train, y_train) 
```




    LinearRegression()




```python
print("Intercept \n",regressor.intercept_)
```

    Intercept 
     2.018160041434683
    


```python
print("coefficient \n",regressor.coef_)
```

    coefficient 
     [9.91065648]
    

VISUALISATION OF THE LINE OF FIT


```python
# Plotting the regression line
line = regressor.coef_*x+regressor.intercept_

# Plotting for the test data
plt.scatter(x,y)
plt.plot(x, line);
plt.show()
```


    
![png](output_20_0.png)
    


PREDICTING THE SCORE FOR 9.25 HRS/DAY


```python
new_x=np.array([[9.25]])
print("PREDICTION OF SCORE FOR STUDENT STUDYING 9.25 HRS/DAY",regressor.predict((new_x)))
```

    PREDICTION OF SCORE FOR STUDENT STUDYING 9.25 HRS/DAY [93.69173249]
    

TESTING THE MODEL


```python
print(x_test) # Testing data - In Hours
y_pred = regressor.predict(x_test) # Predicting the scores
y_pred

```

    [[1.5]
     [3.2]
     [7.4]
     [2.5]
     [5.9]]
    




    array([16.88414476, 33.73226078, 75.357018  , 26.79480124, 60.49103328])




```python
# Comparing Actual vs Predicted
df1 = pd.DataFrame({'Actual': y_test, 'Predicted': y_pred})  
df1

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20</td>
      <td>16.884145</td>
    </tr>
    <tr>
      <th>1</th>
      <td>27</td>
      <td>33.732261</td>
    </tr>
    <tr>
      <th>2</th>
      <td>69</td>
      <td>75.357018</td>
    </tr>
    <tr>
      <th>3</th>
      <td>30</td>
      <td>26.794801</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>60.491033</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn import metrics  
print('Mean Absolute Error:', 
      metrics.mean_absolute_error(y_test, y_pred))
```

    Mean Absolute Error: 4.183859899002975
    


```python
accuracy = regressor.score(x_test,y_test)
print(accuracy*100,'%')
```

    94.54906892105356 %
    


```python
np.mean((y_pred-y_test)**2)
```




    21.5987693072174




```python

```
